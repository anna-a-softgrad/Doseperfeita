﻿Imports Microsoft.VisualBasic
Imports SaleStarLandingPage

Public Class PagSeguroParameters
    Public Shared ProcessorID As Long = 1732
    Public Shared userName As String = "andrew.marciniec@gmail.com"
    Public Shared token As String = "CFE214B860CF436BAF8B17C54DA8F9A8"
    Public Shared GroupPackageID As Integer = 0
End Class
